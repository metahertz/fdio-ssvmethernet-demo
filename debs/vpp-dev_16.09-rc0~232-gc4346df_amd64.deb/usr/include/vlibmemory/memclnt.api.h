/*
 * VLIB API definitions Wed Jul 13 13:48:14 2016
 * Input file: vlibmemory/memclnt.api.h
 * Automatically generated: please edit the input file NOT this file!
 * Copyright (c) 2016 by Cisco Systems, Inc.
 */

#if defined(vl_msg_id)||defined(vl_union_id)||defined(vl_printfun) \
 ||defined(vl_endianfun)|| defined(vl_api_version)||defined(vl_typedefs) \
 ||defined(vl_msg_name)
/* ok, something was selected */
#else
#warning no content included from vlibmemory/memclnt.api.h
#endif

#define VL_API_PACKED(x) x __attribute__ ((packed))


/****** Message ID / handler enum ******/

#ifdef vl_msg_id
vl_msg_id(VL_API_MEMCLNT_CREATE, vl_api_memclnt_create_t_handler)
vl_msg_id(VL_API_MEMCLNT_CREATE_REPLY, vl_api_memclnt_create_reply_t_handler)
vl_msg_id(VL_API_MEMCLNT_DELETE, vl_api_memclnt_delete_t_handler)
vl_msg_id(VL_API_MEMCLNT_DELETE_REPLY, vl_api_memclnt_delete_reply_t_handler)
vl_msg_id(VL_API_RX_THREAD_EXIT, vl_api_rx_thread_exit_t_handler)
vl_msg_id(VL_API_RPC_CALL, vl_api_rpc_call_t_handler)
vl_msg_id(VL_API_RPC_REPLY, vl_api_rpc_reply_t_handler)
vl_msg_id(VL_API_GET_FIRST_MSG_ID, vl_api_get_first_msg_id_t_handler)
vl_msg_id(VL_API_GET_FIRST_MSG_ID_REPLY, vl_api_get_first_msg_id_reply_t_handler)
#endif

/****** Message names ******/

#ifdef vl_msg_name
vl_msg_name(vl_api_memclnt_create_t, 1)
vl_msg_name(vl_api_memclnt_create_reply_t, 1)
vl_msg_name(vl_api_memclnt_delete_t, 1)
vl_msg_name(vl_api_memclnt_delete_reply_t, 1)
vl_msg_name(vl_api_rx_thread_exit_t, 1)
vl_msg_name(vl_api_rpc_call_t, 1)
vl_msg_name(vl_api_rpc_reply_t, 1)
vl_msg_name(vl_api_get_first_msg_id_t, 1)
vl_msg_name(vl_api_get_first_msg_id_reply_t, 1)
#endif


/****** Typedefs *****/

#ifdef vl_typedefs

typedef VL_API_PACKED(struct _vl_api_memclnt_create {
    u16 _vl_msg_id;
    i32 ctx_quota;
    u32 context;
    u64 input_queue;
    u8 name[64];
    u32 api_versions[8];
}) vl_api_memclnt_create_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_create_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
    u32 index;
    u32 context;
}) vl_api_memclnt_create_reply_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_delete {
    u16 _vl_msg_id;
    u32 index;
    u64 handle;
}) vl_api_memclnt_delete_t;

typedef VL_API_PACKED(struct _vl_api_memclnt_delete_reply {
    u16 _vl_msg_id;
    i32 response;
    u64 handle;
}) vl_api_memclnt_delete_reply_t;

typedef VL_API_PACKED(struct _vl_api_rx_thread_exit {
    u16 _vl_msg_id;
    u8 dummy;
}) vl_api_rx_thread_exit_t;

typedef VL_API_PACKED(struct _vl_api_rpc_call {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u64 function;
    u8 multicast;
    u8 need_barrier_sync;
    u8 send_reply;
    u8 data[0];
}) vl_api_rpc_call_t;

typedef VL_API_PACKED(struct _vl_api_rpc_reply {
    u16 _vl_msg_id;
    i32 retval;
    u32 context;
}) vl_api_rpc_reply_t;

typedef VL_API_PACKED(struct _vl_api_get_first_msg_id {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    u8 name[64];
}) vl_api_get_first_msg_id_t;

typedef VL_API_PACKED(struct _vl_api_get_first_msg_id_reply {
    u16 _vl_msg_id;
    u32 client_index;
    u32 context;
    i32 retval;
    u16 first_msg_id;
}) vl_api_get_first_msg_id_reply_t;

#endif /* vl_typedefs */

/****** Discriminated Union Definitions *****/

#ifdef vl_union_id


#endif /* vl_union_id */

/****** Print functions *****/

#ifdef vl_printfun

#ifdef LP64
#define _uword_fmt "%lld"
#define _uword_cast (long long)
#else
#define _uword_fmt "%ld"
#define _uword_cast long
#endif

/***** manual: vl_api_memclnt_create_t_print  *****/

static inline void *vl_api_memclnt_create_reply_t_print (vl_api_memclnt_create_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_create_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    vl_print(handle, "index: %u\n", (unsigned) a->index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

/***** manual: vl_api_memclnt_delete_t_print  *****/

static inline void *vl_api_memclnt_delete_reply_t_print (vl_api_memclnt_delete_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_memclnt_delete_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "response: %ld\n", (long) a->response);
    vl_print(handle, "handle: %llu\n", (long long) a->handle);
    return handle;
}

static inline void *vl_api_rx_thread_exit_t_print (vl_api_rx_thread_exit_t *a,void *handle)
{
    vl_print(handle, "vl_api_rx_thread_exit_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "dummy: %u\n", (unsigned) a->dummy);
    return handle;
}

static inline void *vl_api_rpc_call_t_print (vl_api_rpc_call_t *a,void *handle)
{
    vl_print(handle, "vl_api_rpc_call_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "function: %llu\n", (long long) a->function);
    vl_print(handle, "multicast: %u\n", (unsigned) a->multicast);
    vl_print(handle, "need_barrier_sync: %u\n", (unsigned) a->need_barrier_sync);
    vl_print(handle, "send_reply: %u\n", (unsigned) a->send_reply);
    return handle;
}

static inline void *vl_api_rpc_reply_t_print (vl_api_rpc_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_rpc_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    return handle;
}

static inline void *vl_api_get_first_msg_id_t_print (vl_api_get_first_msg_id_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_first_msg_id_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            vl_print(handle, "name[%d]: %u\n", _i, a->name[_i]);
        }
    }
    return handle;
}

static inline void *vl_api_get_first_msg_id_reply_t_print (vl_api_get_first_msg_id_reply_t *a,void *handle)
{
    vl_print(handle, "vl_api_get_first_msg_id_reply_t:\n");
    vl_print(handle, "_vl_msg_id: %u\n", (unsigned) a->_vl_msg_id);
    vl_print(handle, "client_index: %u\n", (unsigned) a->client_index);
    vl_print(handle, "context: %u\n", (unsigned) a->context);
    vl_print(handle, "retval: %ld\n", (long) a->retval);
    vl_print(handle, "first_msg_id: %u\n", (unsigned) a->first_msg_id);
    return handle;
}

#endif /* vl_printfun */


/****** Endian swap functions *****/

#ifdef vl_endianfun

#undef clib_net_to_host_uword
#ifdef LP64
#define clib_net_to_host_uword clib_net_to_host_u64
#else
#define clib_net_to_host_uword clib_net_to_host_u32
#endif

static inline void vl_api_memclnt_create_t_endian (vl_api_memclnt_create_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->ctx_quota = clib_net_to_host_u32(a->ctx_quota);
    a->context = clib_net_to_host_u32(a->context);
    a->input_queue = clib_net_to_host_u64(a->input_queue);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            a->name[_i] = (a->name[_i]);
        }
    }
    {
        int _i;
        for (_i = 0; _i < 8; _i++) {
            a->api_versions[_i] = clib_net_to_host_u32(a->api_versions[_i]);
        }
    }
}

static inline void vl_api_memclnt_create_reply_t_endian (vl_api_memclnt_create_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
    a->index = clib_net_to_host_u32(a->index);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_memclnt_delete_t_endian (vl_api_memclnt_delete_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->index = clib_net_to_host_u32(a->index);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_memclnt_delete_reply_t_endian (vl_api_memclnt_delete_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->response = clib_net_to_host_u32(a->response);
    a->handle = clib_net_to_host_u64(a->handle);
}

static inline void vl_api_rx_thread_exit_t_endian (vl_api_rx_thread_exit_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->dummy = (a->dummy);
}

static inline void vl_api_rpc_call_t_endian (vl_api_rpc_call_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->function = clib_net_to_host_u64(a->function);
    a->multicast = (a->multicast);
    a->need_barrier_sync = (a->need_barrier_sync);
    a->send_reply = (a->send_reply);
}

static inline void vl_api_rpc_reply_t_endian (vl_api_rpc_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->retval = clib_net_to_host_u32(a->retval);
    a->context = clib_net_to_host_u32(a->context);
}

static inline void vl_api_get_first_msg_id_t_endian (vl_api_get_first_msg_id_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    {
        int _i;
        for (_i = 0; _i < 64; _i++) {
            a->name[_i] = (a->name[_i]);
        }
    }
}

static inline void vl_api_get_first_msg_id_reply_t_endian (vl_api_get_first_msg_id_reply_t *a)
{
    a->_vl_msg_id = clib_net_to_host_u16(a->_vl_msg_id);
    a->client_index = clib_net_to_host_u32(a->client_index);
    a->context = clib_net_to_host_u32(a->context);
    a->retval = clib_net_to_host_u32(a->retval);
    a->first_msg_id = clib_net_to_host_u16(a->first_msg_id);
}

#endif /* vl_endianfun */


#ifdef vl_api_version
vl_api_version(memclnt.api, 0x94d8ded8)

#endif

