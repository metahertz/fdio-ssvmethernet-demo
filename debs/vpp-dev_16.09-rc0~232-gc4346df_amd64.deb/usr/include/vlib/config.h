#define __PRE_DATA_SIZE 128
